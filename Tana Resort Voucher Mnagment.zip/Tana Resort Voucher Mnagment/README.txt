# MikroTik Voucher Manager

A simple web app for receptionists to view, generate, disable and print hotspot vouchers.

## Requirements
- Windows PC with Python 3.8+ installed (https://www.python.org)
- Network access to your MikroTik router

## Setup (one time only)

1. Open `app.py` in Notepad and edit these 3 lines at the top:

   MIKROTIK_HOST = "192.168.88.1"   <- your router's IP
   MIKROTIK_USER = "admin"           <- API username
   MIKROTIK_PASS = ""                <- API password (blank if none)

2. Make sure the RouterOS API is enabled on your MikroTik:
   - Go to IP > Services > api → Enable (port 8728)

3. Also check the hotspot profile names match what you have in:
   IP > Hotspot > User Profiles
   Update the <select> options in templates/index.html if needed.

## Running the app

Double-click `start.bat` — it will:
1. Install dependencies automatically
2. Start the web server
3. Open the browser at http://127.0.0.1:5000

## What the receptionist can do

- View all vouchers with status (Active / Used / Disabled)
- Search/filter vouchers
- Generate 1–50 new vouchers at once with a chosen profile
- Disable or re-enable any voucher
- Delete vouchers
- Select multiple vouchers and print them as cards

## Folder structure

voucher-app/
├── app.py              ← main application + MikroTik config
├── start.bat           ← double-click to run on Windows
├── templates/
│   ├── index.html      ← main page
│   └── print.html      ← printable voucher cards
└── README.txt          ← this file
