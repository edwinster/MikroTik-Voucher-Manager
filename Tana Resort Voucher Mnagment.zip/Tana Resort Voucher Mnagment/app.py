import routeros_api
import random
import string
import os
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from datetime import datetime

app = Flask(__name__)
app.secret_key = "tana-grand-resort-2024"

MIKROTIK_HOST = "192.168.0.1"
MIKROTIK_USER = "admin"
MIKROTIK_PASS = "1234"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def get_connection():
    try:
        pool = routeros_api.RouterOsApiPool(
            MIKROTIK_HOST,
            username=MIKROTIK_USER,
            password=MIKROTIK_PASS,
            plaintext_login=True
        )
        return pool.get_api()
    except Exception:
        return None

def get_profiles(api):
    try:
        profiles = api.get_resource("/ip/hotspot/user/profile")
        return [p["name"] for p in profiles.get()]
    except Exception:
        return ["default"]

def generate_code(length=8):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

@app.route("/logo")
def logo():
    return send_from_directory(BASE_DIR, "tana.png")

@app.route("/")
def index():
    api = get_connection()
    vouchers = []
    profiles = []
    error = None
    if api:
        try:
            users = api.get_resource("/ip/hotspot/user")
            vouchers = users.get()
            profiles = get_profiles(api)
        except Exception as e:
            error = str(e)
    else:
        error = "Could not connect to MikroTik. Check MIKROTIK_HOST, MIKROTIK_USER and MIKROTIK_PASS in app.py."
    return render_template("index.html", vouchers=vouchers, profiles=profiles, error=error)

@app.route("/generate", methods=["POST"])
def generate():
    profile = request.form.get("profile", "default")
    comment = request.form.get("comment", "")
    count = int(request.form.get("count", 1))
    api = get_connection()
    if not api:
        flash("Could not connect to MikroTik.", "error")
        return redirect(url_for("index"))
    try:
        users = api.get_resource("/ip/hotspot/user")
        created = []
        for _ in range(count):
            code = generate_code()
            users.add(
                name=code,
                password=code,
                profile=profile,
                comment=comment or f"Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            )
            created.append(code)
        flash(f"Successfully created {len(created)} voucher(s) on profile '{profile}'.", "success")
    except Exception as e:
        flash(f"Error: {str(e)}", "error")
    return redirect(url_for("index"))

@app.route("/delete/<name>", methods=["POST"])
def delete(name):
    api = get_connection()
    if not api:
        flash("Could not connect to MikroTik.", "error")
        return redirect(url_for("index"))
    try:
        users = api.get_resource("/ip/hotspot/user")
        matches = users.get(name=name)
        if matches:
            users.remove(id=matches[0]["id"])
            flash(f"Voucher {name} deleted.", "success")
        else:
            flash("Voucher not found.", "error")
    except Exception as e:
        flash(f"Error: {str(e)}", "error")
    return redirect(url_for("index"))

@app.route("/disable/<name>", methods=["POST"])
def disable(name):
    api = get_connection()
    if not api:
        flash("Could not connect to MikroTik.", "error")
        return redirect(url_for("index"))
    try:
        users = api.get_resource("/ip/hotspot/user")
        matches = users.get(name=name)
        if matches:
            current = matches[0].get("disabled", "false")
            new_val = "true" if current == "false" else "false"
            users.set(id=matches[0]["id"], disabled=new_val)
            action = "disabled" if new_val == "true" else "re-enabled"
            flash(f"Voucher {name} {action}.", "success")
    except Exception as e:
        flash(f"Error: {str(e)}", "error")
    return redirect(url_for("index"))

@app.route("/print_vouchers")
def print_vouchers():
    ids = request.args.getlist("ids")
    api = get_connection()
    vouchers = []
    if api and ids:
        try:
            users = api.get_resource("/ip/hotspot/user")
            all_users = users.get()
            vouchers = [u for u in all_users if u.get("name") in ids]
        except Exception:
            pass
    return render_template("print.html", vouchers=vouchers)

if __name__ == "__main__":
    import webbrowser
    webbrowser.open("http://127.0.0.1:5000")
    app.run(debug=False)
